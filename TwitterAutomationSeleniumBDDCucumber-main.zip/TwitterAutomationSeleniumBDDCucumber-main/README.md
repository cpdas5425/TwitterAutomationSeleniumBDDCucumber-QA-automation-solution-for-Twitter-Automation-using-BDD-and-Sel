# TwitterAutomationSeleniumBDDCucumber
QA automation solution for Twitter Automation using BDD and Selenium
 Please write source - QA automation solution for below requirements .That is testable and executable using bdd,cucumber etc .

a.       Login to Twitter.com website with username and password .

Create feature files and step definitions for testing the login process. Mandatory Field Validations for username and password have to be done on the Twitter webpage.

b.      Navigate profile page of logged user and upload a profile picture. ”. Create feature files and step definitions to upload  profile on the Twitter profile page.

c.       Update BIO field in profile section as “Selenium Automation user”. Create feature files and step definitions to update location on the Twitter profile page.

d.      Update location dropdown as your city . Create feature files and step definitions to update location on the Twitter profile page.

e.      Update website filed as “twitter.com” . Create feature files and step definitions to update website on the Twitter profile page.

f.        Fetch BIO field ,location and website and check if the submit values got updated on the profile page. Create feature files and step definitions to verify details on the Twitter profile page.

g.       Open the twitter page of The Times of India  and retrieve the tweets that were published in last  2 hrs .

Create feature files and step definitions for above step.

h.      split extra-long tweets (greater than 50 chars) into multiple tweets with markings 1/3, 2/3, 3/3, etc.

Create feature files and step definitions to validate extra-long tweets are marked properly.
